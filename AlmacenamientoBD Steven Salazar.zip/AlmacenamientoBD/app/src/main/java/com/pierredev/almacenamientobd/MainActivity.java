package com.pierredev.almacenamientobd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etCedula, etNombre, etTelefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etCedula=(EditText) findViewById(R.id.etCedula);
        etNombre=(EditText) findViewById(R.id.etNombre);
        etTelefono=(EditText) findViewById(R.id.etTelefono);
    }

//  METODO PARA REGISTRAR USUARIO
    public void registrar(View view) {
//      Abrir base de datos
        AdminBD adminBD = new AdminBD(this,"BaseDatos",null,1);
        SQLiteDatabase BaseDatos = adminBD.getWritableDatabase();

//      Variables donde se almacenaran los datos
        String cedula = etCedula.getText().toString();
        String nombre = etNombre.getText().toString();
        String telefono = etTelefono.getText().toString();

//      Solicitar a usuario que ingrese información en esas variables
         if (!cedula.trim().isEmpty() && !nombre.trim().isEmpty() && !telefono.trim().isEmpty()) {
            ContentValues registro = new ContentValues();
//
//          Llevar registros de las variables a entidades de la tabla
            registro.put("cedula", cedula);
            registro.put("nombre", nombre);
            registro.put("telefono", telefono);

//          Insertar información a la table
            BaseDatos.insert("usuario", null, registro);

//          Cerrar base de datos
            BaseDatos.close();

//          Limpiar campos
            etCedula.setText("");
            etNombre.setText("");
            etTelefono.setText("");

//          Mensaje de almacenamiento o error
            Toast.makeText(this,"Registro almacenado exitosamente", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(this, "Ingrese correctamente todos los datos", Toast.LENGTH_LONG).show();
        }
    }

//  METODO PARA CONSULTAR USUARIO
    public void consultar(View view) {
//      Abrir base de datos
        AdminBD admin = new AdminBD(this,"BaseDatos",null,1);
        SQLiteDatabase BasedeDatos = admin.getWritableDatabase();

//      Variables donde se almacenaran los datos
        String cedula1 = etCedula.getText().toString();

//      Realizar busqueda con "Cedula"
        if (!cedula1.trim().isEmpty()){
//          Sentencia Sql para llamar datos
            Cursor fila = BasedeDatos.rawQuery("select nombre, telefono from usuario where cedula = " + cedula1, null);

//          Condicional para mostrar información
//          "moveToFirst()" mueve la información encontrada por la sentencia SQL, posicionandola arriba de la tabla
            if (fila.moveToFirst()) {
                etNombre.setText(fila.getString(0));
                etTelefono.setText(fila.getString(1));

                // Cerrar cursor
                fila.close();
                // Cerrar base de datos
                BasedeDatos.close();
            }
            else {
                Toast.makeText(this,"No se encontro usuario", Toast.LENGTH_LONG).show();
            }
        }

    }
}